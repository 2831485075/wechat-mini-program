import wepy from './weapp/wepy';

export default wepy;
