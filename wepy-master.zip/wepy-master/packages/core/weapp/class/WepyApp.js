import Base from './Base';

export default class WepyApp extends Base {
  constructor() {
    super();
  }
}
