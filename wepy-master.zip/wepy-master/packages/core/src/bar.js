const bar = num => {
  return num - 1;
};

export { bar };
