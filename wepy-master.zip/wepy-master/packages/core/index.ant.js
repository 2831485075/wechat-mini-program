import wepy from './ant/wepy';

export default wepy;
