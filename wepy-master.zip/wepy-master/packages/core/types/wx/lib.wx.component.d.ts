// @ts-ignore
/// <reference path="../../node_modules/miniprogram-api-typings/types/wx/lib.wx.component.d.ts" />
// @ts-ignore
/// <reference path="../../node_modules/miniprogram-api-typings/types/wx/lib.wx.component.d.ts" />