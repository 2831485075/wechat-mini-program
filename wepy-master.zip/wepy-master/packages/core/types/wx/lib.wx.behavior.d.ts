// @ts-ignore
/// <reference path="../../node_modules/miniprogram-api-typings/types/wx/lib.wx.behavior.d.ts" />
// @ts-ignore
/// <reference path="../../../node_modules/miniprogram-api-typings/types/wx/lib.wx.app.d.ts" />