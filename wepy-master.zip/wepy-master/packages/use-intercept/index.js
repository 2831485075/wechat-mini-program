import install from './install';

export default {
  install,
  version: __VERSION__
};
