import { mapState, mapActions } from './helper';
import install from './install';

export default {
  install,
  version: __VERSION__
};
export { mapState, mapActions };
