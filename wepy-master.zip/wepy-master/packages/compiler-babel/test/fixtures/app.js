import wepy from '@wepy/core'

wepy.app({
  onLaunch() {
    console.log('on launch')
  }
});

