## 实例属性

### this.$router

- **类型**：Object

  router 对象实例

- **参考**：跟全局 router 对象一致，[参考](router.md)

### this.$route

- **类型**：Object

  route 对象实例

- **参考**：跟全局 router.route 对象一致，[参考](router.md#route)
