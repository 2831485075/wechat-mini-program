exports = module.exports = {
  EVENT_DISPATCHER: '__dispatcher',
  VENDOR_DIR: '$vendor',
  WEAPP_EXT: '.$weapp'
};
