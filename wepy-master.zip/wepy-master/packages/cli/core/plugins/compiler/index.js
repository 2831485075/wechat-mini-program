exports = module.exports = function() {
  require('./common').call(this);
  require('./wxss').call(this);
  require('./before').call(this);
};
