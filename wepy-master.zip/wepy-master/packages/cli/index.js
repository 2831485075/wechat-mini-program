exports = module.exports = require('./core/compile.js');
