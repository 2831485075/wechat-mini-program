function proxy (item) {
  var _vm = this;
  return (function () {
    _vm.myClickInFor(item);
  })();
}
