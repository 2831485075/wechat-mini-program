function proxy () {
  var _vm = this;
  return (function () {
    _vm.myclick(1);
  })();
}
