module.exports = {
  publish: false
};
